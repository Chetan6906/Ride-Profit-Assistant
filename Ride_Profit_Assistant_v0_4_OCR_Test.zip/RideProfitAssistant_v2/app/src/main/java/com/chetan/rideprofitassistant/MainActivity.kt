package com.chetan.rideprofitassistant

import android.app.Activity
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private val captureRequest = 401
    private val bg = Color.rgb(16,24,39)
    private val mint = Color.rgb(39,211,162)
    private lateinit var result: TextView
    private lateinit var ocrStatus: TextView
    private lateinit var fareField: EditText
    private lateinit var pickupField: EditText
    private lateinit var dropField: EditText
    private lateinit var platform: Spinner
    private val ocrReceiver = object: BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            parseRideText(intent?.getStringExtra("ocrText") ?: return)
        }
    }
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor=bg; window.navigationBarColor=bg
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(22),dp(20),dp(20)); setBackgroundColor(bg) }
        val scroll=ScrollView(this)
        val body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        scroll.addView(body)
        val head=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        head.addView(ImageView(this).apply { setImageResource(R.drawable.ic_ride_logo); layoutParams=LinearLayout.LayoutParams(dp(54),dp(54)) })
        head.addView(TextView(this).apply { text="RIDE PROFIT\nASSISTANT"; setTextColor(Color.WHITE); textSize=18f; setTypeface(null,Typeface.BOLD); setPadding(dp(12),0,0,0) })
        body.addView(head)
        body.addView(label("Ride ka hisaab, turant.",mint,22f,true))
        body.addView(label("Ola/Uber: app mein dikhne wala actual ride fare enter karo. Rapido: sirf drop KM se estimate. Pickup + drop dono ka kharcha count hoga.",Color.LTGRAY,14f,false))
        body.addView(label("RIDE PROFIT CALCULATOR",Color.WHITE,14f,true))
        platform=Spinner(this)
        platform.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Rapido – estimate fare","Ola – shown fare","Uber – shown fare"))
        body.addView(platform)
        val base=field("Rapido base estimate (₹)","25")
        val rate=field("Rapido rate per DROP KM (₹)","14")
        fareField=field("Ola/Uber mein ride card par dikhne wala fare (₹)","")
        val fare=fareField
        val deduction=field("Extra/platform deduction (₹), agar ho","0")
        pickupField=field("Pickup distance (KM)","")
        dropField=field("Drop distance (KM)","")
        val pickup=pickupField
        val drop=dropField
        val cng=field("CNG price (₹/kg)","98.5")
        val mileage=field("Car mileage (KM/kg)","25")
        val maint=field("Maintenance (₹/total KM)","2")
        listOf(base,rate,fare,deduction,pickup,drop,cng,mileage,maint).forEach{body.addView(it)}
        val calc=Button(this).apply {
            text="CALCULATE PROFIT"; setTextColor(bg); backgroundTintList=android.content.res.ColorStateList.valueOf(mint)
            setOnClickListener {
                val p=pickup.text.toString().toDoubleOrNull()?:0.0
                val d=drop.text.toString().toDoubleOrNull()?:0.0
                val total=p+d; val rapido=platform.selectedItemPosition==0
                val shownOrEstimate=if(rapido) (base.text.toString().toDoubleOrNull()?:25.0)+(rate.text.toString().toDoubleOrNull()?:14.0)*d else fare.text.toString().toDoubleOrNull()?:0.0
                val amount=shownOrEstimate-(deduction.text.toString().toDoubleOrNull()?:0.0)
                val cp=cng.text.toString().toDoubleOrNull()?:98.5
                val mi=mileage.text.toString().toDoubleOrNull()?:25.0
                val mt=maint.text.toString().toDoubleOrNull()?:2.0
                val fuel=if(mi>0) total/mi*cp else 0.0
                val upkeep=total*mt; val net=amount-fuel-upkeep
                result.text=(if(rapido)"Rapido estimated fare (before extra deduction)" else "Ola/Uber shown fare (before extra deduction)")+": ₹${"%.0f".format(shownOrEstimate)}\nExtra/platform deduction: ₹${"%.1f".format(deduction.text.toString().toDoubleOrNull()?:0.0)}\nFare after deduction: ₹${"%.1f".format(amount)}\nTotal running: ${"%.1f".format(total)} KM\nCNG: ₹${"%.1f".format(fuel)}\nMaintenance: ₹${"%.1f".format(upkeep)}\nEstimated net: ₹${"%.1f".format(net)}"
                result.setTextColor(if(net>=0)mint else Color.rgb(255,110,110))
            }
        }
        body.addView(calc)
        result=TextView(this).apply { text="Calculation yahan dikhega"; textSize=17f; setTextColor(Color.WHITE); setPadding(dp(16),dp(16),dp(16),dp(16)); setBackgroundColor(Color.rgb(28,40,59)) }
        body.addView(result)
        body.addView(label("Ola/Uber ke liye app par jo fare dikh raha hai wahi enter hota hai—koi fare estimate nahi. Rapido ke liye default ₹25 base + ₹14 per DROP KM editable assumption hai, official tariff nahi. Pickup + drop KM dono CNG aur maintenance mein count hote hain. Agar app ka shown amount driver payout nahi hai, actual payout/commission ko deduction field mein adjust karo.",Color.LTGRAY,13f,false))
        ocrStatus=label("OCR: permission start karo; ride card detect hone par details yahan aayengi.",Color.YELLOW,13f,false)
        body.addView(ocrStatus)
        body.addView(label("OCR screen par visible text read karta hai. App layout/overlay badalne par reading miss ho sakti hai; fare aur KM accept karne se pehle verify karo.",Color.LTGRAY,12f,false))
        body.addView(label("FLOATING BUBBLE & SCREEN PERMISSION",Color.WHITE,14f,true))
        body.addView(action("Allow floating bubble") {
            if(!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))
            else Toast.makeText(this,"Permission already allowed",Toast.LENGTH_SHORT).show()
        })
        body.addView(action("Start floating calculator") {
            if(Settings.canDrawOverlays(this)) startService(Intent(this,FloatingService::class.java))
            else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))
        })
        body.addView(action("Start screen-reading permission") {
            val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mgr.createScreenCaptureIntent(),captureRequest)
        })
        body.addView(action("STOP screen reading") { stopService(Intent(this,CaptureService::class.java)); Toast.makeText(this,"Screen reading stopped",Toast.LENGTH_SHORT).show() })
        root.addView(scroll); setContentView(root)
        val filter=IntentFilter(CaptureService.ACTION_OCR)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(ocrReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(ocrReceiver, filter)
    }

    private fun parseRideText(raw: String) {
        val t=raw.replace(",", "")
        val kmRegex=Regex("""(?i)(\d+(?:\.\d+)?)\s*km""")
        val kms=kmRegex.findAll(t).mapNotNull { it.groupValues[1].toDoubleOrNull() }.toList()
        val money=Regex("""₹\s*(\d+(?:\.\d{1,2})?)""").find(t)?.groupValues?.get(1)?.toDoubleOrNull()
        val lower=t.lowercase()
        val detected=when {
            lower.contains("uber") -> 2
            lower.contains("prime sedan") || lower.contains("booking incoming") -> 1
            lower.contains("rapido") || (kms.size>=2 && lower.contains("cab")) -> 0
            else -> -1
        }
        if (detected>=0) platform.setSelection(detected)
        if (kms.size>=2) {
            pickupField.setText(kms[0].toString())
            dropField.setText(kms[1].toString())
        }
        if (money!=null && detected!=0) fareField.setText(money.toString())
        val appName=when(detected){0->"Rapido";1->"Ola";2->"Uber";else->"Ride"}
        val fareText=if(detected==0 && money==null) "Fare nahi dikha — Rapido estimate mode" else if(money!=null) "Fare ₹${"%.2f".format(money)}" else "Fare detect nahi hua"
        ocrStatus.text="OCR detected: $appName | ${if(kms.size>=2) "Pickup ${kms[0]} km, Drop ${kms[1]} km" else "KM clear nahi mile"} | $fareText"
        ocrStatus.setTextColor(mint)
    }

    override fun onDestroy() {
        try { unregisterReceiver(ocrReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun label(s:String,color:Int,size:Float,bold:Boolean)=TextView(this).apply {
        text=s; setTextColor(color); textSize=size; if(bold)setTypeface(null,Typeface.BOLD); setPadding(0,dp(12),0,dp(8))
    }
    private fun field(h:String,v:String)=EditText(this).apply {
        hint=h; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); textSize=15f; setSingleLine(true)
        if(v.isNotEmpty())setText(v)
        inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        setPadding(dp(12),dp(8),dp(12),dp(8)); backgroundTintList=android.content.res.ColorStateList.valueOf(Color.GRAY)
    }
    private fun action(t:String,fn:()->Unit)=Button(this).apply{text=t;setOnClickListener{fn()}}
    @Deprecated("Prototype callback")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==captureRequest&&resultCode==RESULT_OK&&data!=null){
            val i=Intent(this,CaptureService::class.java).apply{putExtra("resultCode",resultCode);putExtra("projectionData",data)}
            startForegroundService(i)
        }
    }
}
