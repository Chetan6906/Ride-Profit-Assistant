package com.chetan.rideprofitassistant
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
class FloatingService:Service(){
 private var wm:WindowManager?=null; private var bubble:TextView?=null
 override fun onCreate(){super.onCreate();wm=getSystemService(WINDOW_SERVICE) as WindowManager
  bubble=TextView(this).apply{text="RP";textSize=16f;setTextColor(0xFF101827.toInt());setBackgroundColor(0xFF27D3A2.toInt());setPadding(22,16,22,16);elevation=14f
   setOnClickListener{startActivity(Intent(this@FloatingService,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))}
  }
  val p=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.END;x=22;y=230}
  wm?.addView(bubble,p)
 }
 override fun onDestroy(){bubble?.let{wm?.removeView(it)};bubble=null;super.onDestroy()}
 override fun onBind(intent:Intent?):IBinder?=null
}
