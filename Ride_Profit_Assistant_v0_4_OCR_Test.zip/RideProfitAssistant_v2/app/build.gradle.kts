plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.chetan.rideprofitassistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.chetan.rideprofitassistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "0.4"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
