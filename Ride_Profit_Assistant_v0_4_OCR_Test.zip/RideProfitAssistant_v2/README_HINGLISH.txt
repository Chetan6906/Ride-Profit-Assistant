RIDE PROFIT ASSISTANT v0.4 — OCR TEST BUILD

What changed:
- Uses Android MediaProjection (system consent) + Google ML Kit on-device text recognition.
- Tries to read visible ride-card text repeatedly and fills pickup/drop KM and visible fare.
- Detects common labels in the supplied example layouts: Uber Go AC, Ola Prime Sedan/booking incoming, Rapido/Cab.
- Rapido with no visible fare remains in estimate mode using editable base + per-drop-KM assumptions.
- Floating bubble and existing cost calculator remain.

IMPORTANT:
- This is an OCR test build, not a guaranteed production detector. It scans the whole visible screen, not only a specific app; notifications/other text can confuse it.
- The sample screenshots are layout examples. Real live ride screens, different app versions, scaling and popups may affect OCR.
- Verify detected values before deciding. It does not accept/reject rides.
- Screen capture is visible to Android and can be stopped by Android's screen-sharing notification or the app's STOP control.
- No contacts, SMS, microphone, camera or location permission is requested.
- Ola/Uber amount may include tips or differ from actual driver payout. Verify payout/commission.
- Rapido estimate formula is only an editable assumption, not official fare data.

BUILD ON GITHUB MOBILE:
1. Open your Ride-Profit-Assistant repository.
2. Delete the old ZIP in repository root.
3. Upload this ZIP to repository root.
4. Ensure only this one project ZIP remains in root (the existing workflow extracts the first ZIP it finds).
5. Commit changes. Open Actions and wait for Android build to finish.
6. Download the Ride-Profit-Assistant-APK artifact, extract it, install app-debug.apk.
7. Open app, allow floating bubble, start floating calculator, then start screen-reading permission.
8. Keep app screen reading active while ride cards appear. Test with screenshots/real incoming ride cards and report what it detects.

If Gradle build fails, share the red error screenshot; do not upload multiple project ZIPs.
