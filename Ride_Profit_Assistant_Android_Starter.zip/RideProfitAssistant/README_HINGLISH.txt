RIDE PROFIT ASSISTANT — ANDROID STARTER PROJECT

Status:
- Ye Android Studio source project hai, ready-made APK nahi.
- Floating bubble ka basic prototype included hai.
- Android screen-capture consent flow ka starter included hai.
- Abhi automatic screen frame OCR, Ola/Uber/Rapido layout detection, aur live profit calculation implemented nahi hain. Isliye ise abhi ride par rely karke use mat karna.

Build:
1. Computer par Android Studio install karo.
2. Android Studio > Open > is ZIP ko extract karke RideProfitAssistant folder select karo.
3. Gradle sync complete hone do.
4. Android 15 phone USB debugging se connect karo.
5. Run button dabao; ya Build > Build APK(s).

Permissions:
- Floating bubble: Display over other apps.
- Screen read: Android ka system consent popup, har session ke liye.
- Notification: Android version/settings ke hisaab se.
No contacts, SMS, calls, microphone, camera, or location permission is requested.

Important:
This is a development starter, not a tested production app. Android 15 / OEM background limits may affect behavior.
Screen capture may expose sensitive content from other apps. Start it only while using the ride app and stop it when finished. The next development step is on-device OCR with ML Kit, then platform-specific text parsing and a confidence check before showing any estimate.
